/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author aless
 */
import java.io.*;
import java.util.Properties;

public class PropertiesManager {
    private static final String FILE_PATH = "contacts.properties";

    // 🔹 Salvar os vetores em um arquivo .properties
    public static void saveToProperties(String[] nomes, int[] numeros, String[] descricoes) {
        Properties props = new Properties();

        for (int i = 0; i < nomes.length; i++) {
            if (nomes[i] != null && !nomes[i].isEmpty()) {
                props.setProperty("nome" + i, nomes[i]);
                props.setProperty("numero" + i, String.valueOf(numeros[i]));
                props.setProperty("descricao" + i, descricoes[i]);
            }
        }

        try (FileOutputStream fos = new FileOutputStream(FILE_PATH)) {
            props.store(fos, "Lista de Contatos");
            System.out.println("Contatos salvos com sucesso!");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 🔹 Carregar os vetores do arquivo .properties
    public static void loadFromProperties(String[] nomes, int[] numeros, String[] descricoes) {
        Properties props = new Properties();

        try (FileInputStream fis = new FileInputStream(FILE_PATH)) {
            props.load(fis);

            for (int i = 0; i < nomes.length; i++) {
                nomes[i] = props.getProperty("nome" + i, "");
                numeros[i] = Integer.parseInt(props.getProperty("numero" + i, "0"));
                descricoes[i] = props.getProperty("descricao" + i, "");
            }

            System.out.println("Contatos carregados com sucesso!");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
}